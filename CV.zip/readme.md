[Gå in på sidan här](https://lauax.github.io/CV/)

Här är mitt CV och jag hoppas att ni ser mig som intressant sökande och förhoppningsvis kan jag komma på en intervju.
Med Vänliga Hälsningar Lucas Alfredsson
Mail : lucas12alfredsson@gmail.com
